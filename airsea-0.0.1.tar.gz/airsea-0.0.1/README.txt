python-airsea
=============

| This module is a translation of the original AIRSEA-2.0 MATLAB toolbox
| routines for calculating the properties of airsea fluxes.
